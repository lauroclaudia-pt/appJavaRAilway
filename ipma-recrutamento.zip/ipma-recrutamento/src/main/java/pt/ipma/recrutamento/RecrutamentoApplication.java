package pt.ipma.recrutamento;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RecrutamentoApplication {
    public static void main(String[] args) {
        SpringApplication.run(RecrutamentoApplication.class, args);
    }
}
